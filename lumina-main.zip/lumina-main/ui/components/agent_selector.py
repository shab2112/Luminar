import streamlit as st

def render_agent_selector(domain):
    return []
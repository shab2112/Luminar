class ResultConsolidator:
    pass
class AgentCoordinator:
    pass
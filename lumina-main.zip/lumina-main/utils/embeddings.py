def generate_embeddings(text):
    pass
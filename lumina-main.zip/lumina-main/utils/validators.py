def validate_query(query):
    return len(query) > 0
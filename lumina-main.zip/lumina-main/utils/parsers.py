def parse_response(response):
    return {}
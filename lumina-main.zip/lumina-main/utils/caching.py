def cache_result(key, value):
    return value
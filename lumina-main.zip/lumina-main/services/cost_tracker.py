class CostTracker:
    pass
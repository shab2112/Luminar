class YouTubeClient:
    pass
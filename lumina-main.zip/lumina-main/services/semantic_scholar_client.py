class SemanticScholarClient:
    pass
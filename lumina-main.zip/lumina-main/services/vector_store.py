class VectorStore:
    pass
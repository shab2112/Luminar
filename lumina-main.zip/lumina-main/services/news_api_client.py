class NewsAPIClient:
    pass
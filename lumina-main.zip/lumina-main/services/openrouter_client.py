class OpenRouterClient:
    pass
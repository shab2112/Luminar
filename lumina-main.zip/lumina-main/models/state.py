from typing import TypedDict

class ResearchState(TypedDict):
    query: str